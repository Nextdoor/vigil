# vigil-controller

![Version: 0.1.0](https://img.shields.io/badge/Version-0.1.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.1.0](https://img.shields.io/badge/AppVersion-0.1.0-informational?style=flat-square)

Vigil — Node Readiness Controller for DaemonSet-Aware Startup Taints

**Homepage:** <https://github.com/Nextdoor/vigil>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Vigil Controller Maintainers |  | <https://github.com/Nextdoor/vigil> |

## Source Code

* <https://github.com/Nextdoor/vigil>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity rules |
| config | object | `{"excludeDaemonSets":{"byName":[]},"startupTaintKeys":["node.nextdoor.com/initializing","cni.istio.io/not-ready","ebs.csi.aws.com/agent-not-ready","efs.csi.aws.com/agent-not-ready"],"taintEffect":"NoSchedule","taintKey":"node.nextdoor.com/initializing","timeoutSeconds":120}` | Vigil controller configuration |
| controllerManager.enableHttp2 | bool | `false` | Enable HTTP/2 |
| controllerManager.extraArgs | list | `[]` | Extra arguments to pass to the controller |
| controllerManager.healthProbeBindAddress | string | `":8081"` | Health probe bind address |
| controllerManager.leaderElection.enabled | bool | `true` | Enable leader election |
| controllerManager.logLevel | string | `"info"` | Log level (debug, info, warn, error) |
| controllerManager.metricsAuth | bool | `false` | Enable metrics authentication |
| controllerManager.metricsBindAddress | string | `":8080"` | Metrics bind address |
| controllerManager.metricsCerts.certName | string | `"tls.crt"` |  |
| controllerManager.metricsCerts.keyName | string | `"tls.key"` |  |
| controllerManager.metricsCerts.path | string | `""` |  |
| controllerManager.metricsSecure | bool | `false` | Enable metrics TLS |
| controllerManager.webhookCerts.certName | string | `"tls.crt"` |  |
| controllerManager.webhookCerts.keyName | string | `"tls.key"` |  |
| controllerManager.webhookCerts.path | string | `""` |  |
| controllerManager.zap.devel | bool | `false` | Enable development mode logging |
| controllerManager.zap.encoder | string | `"json"` | Log encoder (json or console) |
| controllerManager.zap.stacktraceLevel | string | `"error"` | Stack trace level |
| controllerManager.zap.timeEncoding | string | `"epoch"` | Time encoding |
| fullnameOverride | string | `""` | Override the full name |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| image.repository | string | `"ghcr.io/nextdoor/vigil"` | Container image repository |
| image.tag | string | `""` | Image tag (defaults to Chart appVersion) |
| imagePullSecrets | list | `[]` | Image pull secrets |
| livenessProbe.httpGet.path | string | `"/healthz"` |  |
| livenessProbe.httpGet.port | string | `"health"` |  |
| livenessProbe.initialDelaySeconds | int | `15` |  |
| livenessProbe.periodSeconds | int | `20` |  |
| metricsService.annotations | object | `{}` | Metrics service annotations |
| metricsService.port | int | `8080` | Metrics service port |
| metricsService.type | string | `"ClusterIP"` | Metrics service type |
| nameOverride | string | `""` | Override the chart name |
| nodeSelector | object | `{}` | Node selector |
| podAnnotations | object | `{}` | Pod annotations |
| podLabels | object | `{}` | Pod labels |
| podSecurityContext | object | `{"runAsNonRoot":true}` | Pod security context |
| rbac.create | bool | `true` | Create RBAC resources |
| readinessProbe.httpGet.path | string | `"/readyz"` |  |
| readinessProbe.httpGet.port | string | `"health"` |  |
| readinessProbe.initialDelaySeconds | int | `5` |  |
| readinessProbe.periodSeconds | int | `10` |  |
| replicaCount | int | `2` | Number of replicas for the controller deployment |
| resources | object | `{"limits":{"cpu":"500m","memory":"128Mi"},"requests":{"cpu":"100m","memory":"64Mi"}}` | Resource requests and limits |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]}}` | Container security context |
| serviceAccount.annotations | object | `{}` | Annotations for the service account |
| serviceAccount.automount | bool | `true` | Automount API credentials |
| serviceAccount.create | bool | `true` | Create a service account |
| serviceAccount.name | string | `""` | Service account name (generated if not set) |
| serviceMonitor.annotations | object | `{}` | Annotations for the ServiceMonitor |
| serviceMonitor.enabled | bool | `false` | Create a ServiceMonitor resource |
| serviceMonitor.interval | string | `"30s"` | Scrape interval |
| serviceMonitor.labels | object | `{}` | Additional labels for the ServiceMonitor |
| serviceMonitor.metricRelabelings | list | `[]` | Metric relabeling configs |
| serviceMonitor.relabelings | list | `[]` | Relabeling configs |
| serviceMonitor.scrapeTimeout | string | `"10s"` | Scrape timeout |
| skipConfig | bool | `false` | Skip loading the config file (use CLI flags only) |
| tolerations | list | `[]` | Tolerations |
| volumeMounts | list | `[]` | Additional volume mounts |
| volumes | list | `[]` | Additional volumes |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
