# vigil-controller

![Version: 0.6.2](https://img.shields.io/badge/Version-0.6.2-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 0.6.2](https://img.shields.io/badge/AppVersion-0.6.2-informational?style=flat-square)

Vigil — Node Readiness Controller for DaemonSet-Aware Startup Taints

**Homepage:** <https://github.com/Nextdoor/vigil>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Vigil Controller Maintainers |  | <https://github.com/Nextdoor/vigil> |

## Source Code

* <https://github.com/Nextdoor/vigil>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Affinity rules |
| config | object | `{"dryRun":false,"excludeDaemonSets":{"byName":[]},"knownStartupTaintKeys":["node.nextdoor.com/initializing","cni.istio.io/not-ready","ebs.csi.aws.com/agent-not-ready","efs.csi.aws.com/agent-not-ready"],"maxConcurrentReconciles":10,"taintEffect":"NoSchedule","taintKey":"node.nextdoor.com/initializing","timeoutSeconds":120}` | Vigil controller configuration |
| config.knownStartupTaintKeys | list | `["node.nextdoor.com/initializing","cni.istio.io/not-ready","ebs.csi.aws.com/agent-not-ready","efs.csi.aws.com/agent-not-ready"]` | All known temporary startup taint keys used in the cluster. Vigil only removes the taint specified by taintKey. However, new nodes often have additional temporary taints set by other controllers (CSI drivers, CNI plugins, etc.). Those controllers remove their own taints — Vigil does not touch them.  This list is used solely for DaemonSet discovery: when determining which DaemonSets should run on a node in steady state, Vigil strips these taints before evaluating scheduling predicates. Without this, DaemonSets that don't tolerate these temporary taints would be incorrectly excluded from Vigil's expected set, causing it to remove its taint too early.  Must include taintKey itself. Add any other startup taints used by your infrastructure (CSI drivers, CNI plugins, GPU initializers, etc.). |
| controllerManager.enableHttp2 | bool | `false` | Enable HTTP/2 |
| controllerManager.extraArgs | list | `[]` | Extra arguments to pass to the controller |
| controllerManager.healthProbeBindAddress | string | `":8081"` | Health probe bind address |
| controllerManager.leaderElection.enabled | bool | `true` | Enable leader election |
| controllerManager.leaderElection.leaseDuration | string | `"15s"` | Duration that non-leader candidates will wait to force acquire leadership. Shorter values mean faster failover but more API server load. |
| controllerManager.leaderElection.renewDeadline | string | `"10s"` | Duration the acting leader will retry refreshing leadership before giving up. Must be less than leaseDuration. |
| controllerManager.leaderElection.retryPeriod | string | `"2s"` | Duration between leader election retry attempts. Must be less than renewDeadline. |
| controllerManager.logLevel | string | `"info"` | Log level (debug, info, warn, error) |
| controllerManager.metricsAuth | bool | `false` | Enable metrics authentication |
| controllerManager.metricsBindAddress | string | `":8080"` | Metrics bind address |
| controllerManager.metricsCerts.certName | string | `"tls.crt"` |  |
| controllerManager.metricsCerts.keyName | string | `"tls.key"` |  |
| controllerManager.metricsCerts.path | string | `""` |  |
| controllerManager.metricsSecure | bool | `false` | Enable metrics TLS |
| controllerManager.webhookCerts.certName | string | `"tls.crt"` |  |
| controllerManager.webhookCerts.keyName | string | `"tls.key"` |  |
| controllerManager.webhookCerts.path | string | `""` |  |
| controllerManager.zap.devel | bool | `false` | Enable development mode logging |
| controllerManager.zap.encoder | string | `"json"` | Log encoder (json or console) |
| controllerManager.zap.stacktraceLevel | string | `"error"` | Stack trace level |
| controllerManager.zap.timeEncoding | string | `"epoch"` | Time encoding |
| fullnameOverride | string | `""` | Override the full name |
| image.pullPolicy | string | `"IfNotPresent"` | Image pull policy |
| image.repository | string | `"ghcr.io/nextdoor/vigil"` | Container image repository |
| image.tag | string | `""` | Image tag (defaults to Chart appVersion) |
| imagePullSecrets | list | `[]` | Image pull secrets |
| livenessProbe.httpGet.path | string | `"/healthz"` |  |
| livenessProbe.httpGet.port | string | `"health"` |  |
| livenessProbe.initialDelaySeconds | int | `15` |  |
| livenessProbe.periodSeconds | int | `20` |  |
| metricsService.annotations | object | `{}` | Metrics service annotations |
| metricsService.port | int | `8080` | Metrics service port |
| metricsService.type | string | `"ClusterIP"` | Metrics service type |
| nameOverride | string | `""` | Override the chart name |
| nodeSelector | object | `{}` | Node selector |
| podAnnotations | object | `{}` | Pod annotations |
| podDisruptionBudget.enabled | bool | `true` | Enable PodDisruptionBudget |
| podDisruptionBudget.minAvailable | int | `1` | Minimum number of pods that must be available |
| podLabels | object | `{}` | Pod labels |
| podSecurityContext | object | `{"runAsNonRoot":true}` | Pod security context |
| priorityClassName | string | `""` | Priority class name for the controller pods |
| rbac.create | bool | `true` | Create RBAC resources |
| readinessProbe.httpGet.path | string | `"/readyz"` |  |
| readinessProbe.httpGet.port | string | `"health"` |  |
| readinessProbe.initialDelaySeconds | int | `5` |  |
| readinessProbe.periodSeconds | int | `10` |  |
| replicaCount | int | `2` | Number of replicas for the controller deployment |
| resources | object | `{"limits":{"cpu":"500m","memory":"128Mi"},"requests":{"cpu":"100m","memory":"64Mi"}}` | Resource requests and limits |
| securityContext | object | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]}}` | Container security context |
| serviceAccount.annotations | object | `{}` | Annotations for the service account |
| serviceAccount.automount | bool | `true` | Automount API credentials |
| serviceAccount.create | bool | `true` | Create a service account |
| serviceAccount.name | string | `""` | Service account name (generated if not set) |
| serviceMonitor.annotations | object | `{}` | Annotations for the ServiceMonitor |
| serviceMonitor.enabled | bool | `false` | Create a ServiceMonitor resource |
| serviceMonitor.interval | string | `"30s"` | Scrape interval |
| serviceMonitor.labels | object | `{}` | Additional labels for the ServiceMonitor |
| serviceMonitor.metricRelabelings | list | `[]` | Metric relabeling configs |
| serviceMonitor.relabelings | list | `[]` | Relabeling configs |
| serviceMonitor.scrapeTimeout | string | `"10s"` | Scrape timeout |
| skipConfig | bool | `false` | Skip loading the config file (use CLI flags only) |
| tolerations | list | `[]` | Tolerations |
| volumeMounts | list | `[]` | Additional volume mounts |
| volumes | list | `[]` | Additional volumes |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
